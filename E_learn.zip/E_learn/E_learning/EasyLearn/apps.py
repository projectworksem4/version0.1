from django.apps import AppConfig


class EasylearnConfig(AppConfig):
    name = 'EasyLearn'
